function keithleyRelease(keithley);

% set to local mode
fprintf(keithley,'SYSTEM:KEY 23');
% fclose(keithley);
